/* put your DOM code here */
$(function() {
	var img = $('<img src="images/art/thumbs/13030.jpg">');
	var panel = $('.panel');
	img.insertBefore(panel);
});
