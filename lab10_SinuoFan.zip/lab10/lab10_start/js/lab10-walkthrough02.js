/* try the different selection calls here */
var msg = $('#msgArea');
msg.val("here is some new text");

$("#pageTitle").html("new Title");
$('#msgArea').val("My class is " + $('#msgArea').attr("class"));
var buttons = $('button');
buttons.css('background-color', 'red');
var temp = $('body');
temp.css("background-color", "ivory");
$('.center-icons').addClass('selected');